filename = input("Masukkan nama file yang ingin diproses: ")

with open(filename, 'r') as f:
    with open('output/dbforcp.txt', 'w') as g:
        data = ""
        for line in f:
            if line.strip() == "":
                continue
            if '|' not in line:
                data += line.strip()
            else:
                data += line.strip()
                data_parts = data.split('|')
                if len(data_parts) >= 4:
                    domain = data_parts[0].replace('http://','').replace('https://','').split('/')[0]
                    data_pilihan = [domain, data_parts[2], data_parts[3]]
                    data_pilihan_string = '|'.join(data_pilihan) + '\n'
                    g.write(data_pilihan_string)
                data = ""
        if data != "":
            print(f"Data tidak lengkap: {data}")