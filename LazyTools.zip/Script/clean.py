import multiprocessing
from multiprocessing.pool import ThreadPool

# fungsi untuk menghapus bagian "http://" atau "https://" dan bagian path dari sebuah URL
def clean_url(url):
    if url.startswith("https://"):
        url = url[8:]
    elif url.startswith("http://"):
        url = url[7:]
    url = url.split("/")[0]
    return url

# meminta pengguna untuk memasukkan nama file yang akan diproses
filename = input("Masukkan nama file yang akan diproses: ")

# membuka file yang akan diproses dan membaca URL
with open(filename, "r") as f:
    urls = f.readlines()

# menghapus bagian "http://" atau "https://" dan bagian path-nya dari setiap URL
clean_urls = set()
for url in urls:
    clean_urls.add(clean_url(url))

# membuat thread pool dengan jumlah worker sebanyak 8
pool = ThreadPool(processes=8)

# menghapus duplikat URL dan menghapus bagian "http://" atau "https://" dan bagian path-nya dari setiap URL menggunakan thread pool
results = []
for url in clean_urls:
    result = pool.apply_async(clean_url, args=(url,))
    results.append(result)

# menampilkan proses penghapusan URL pada layar
# for i, result in enumerate(results):
#   print(f"Processing URL {i+1}/{len(results)}")

# mengambil hasil penghapusan URL dari setiap thread
clean_urls = [result.get() for result in results]

# meminta pengguna untuk memasukkan nama file untuk menyimpan hasil yang sudah di proses
output_filename = input("Masukkan nama file untuk menyimpan hasil yang sudah di proses: ")

# menyimpan hasil yang sudah di proses di file yang ditentukan oleh pengguna
with open(output_filename, "w") as f:
    for url in clean_urls:
        f.write(url + "\n")
