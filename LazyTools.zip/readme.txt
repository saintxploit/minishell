# Gunakan python 3
List module yang diperlukan :
pip install requests
pip install colorama
pip install bs4
pip install paramiko
pip install mysql-connector 



# Penjelasan Sftp/Ftp/SSH Hunter
1. jalankan dulu tools scan 
2. jika result sudah ada lanjut split ftp untuk extra datanya
3. lanjutkan checker otomatis untuk ftp/sftp/ssh yang login



# Penjelasan LazyConfig
1. Lazyconfig = untuk mencari config dari list kalian 
2. clean = digunakan untuk membersihkan domain dari path contoh (http://domain.com/wp-config.php~) menjadi (domain.com)
3. sqlcheck = tools ini mencari path adminer/ phpmyadmin, gunakan list dari hasil clean, dan silakan login manual cek menggunakan data db dari lazyconfig
4. extradb = digunakan untuk mengambil data db|dbnamne|dbuser|dbpass|host:port dari result lazyconfig
5. remotesql = digunakan untuk mengecek koneksi sql apakah bisa di remote atau tidak, list diambil dari hasil extradb
6. extracdb Cp = sama seperti no 4 bedanya hasil extrac digunakan untuk crack cpanel
7. Crackcp = digunakan untuk melakukan test u/p menggunakan data dari no 6


# Tambahan anda dapat menambahkan path pada lazyconfig.py di folder script line ke 53 contoh
lazycfg(star, "/pathanda")



# Ada error langsung dm ajah via facebook
https://www.facebook.com/endang.phtml/

# Thanks for buy 
List domain free  265.236.179 dari https://domains-monitor.com/
link : https://drive.google.com/drive/folders/1owXYNlNRHMmuoCevnHuIMz4ffUrs4Mfo?usp=share_link